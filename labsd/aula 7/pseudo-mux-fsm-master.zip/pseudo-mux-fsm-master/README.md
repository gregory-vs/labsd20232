# pseudo-mux-fsm

An interface definition for a Finite State Machine that mimics the behavior of a MUX 4x1 using just one selection input.
